<!DOCTYPE html>
<?php
$mysql_hostName="localhost";
$mysql_userName="root";
$mysql_password="";
$mysql_database="student";
$conn= mysqli_connect($mysql_hostName, $mysql_userName, $mysql_password, $mysql_database);
if(!$conn){
    die("Connection is fail.". mysqli_connect_error());
}
if($_SERVER["REQUEST_METHOD"]=="POST"){
    $firstname = $_POST["firstname"];
    $lastname = $_POST["lastname"];
    $email = $_POST["email"];
    $gpa = $_POST["gpa"];
    $sql = "INSERT INTO student_01 (firstname,lastname,email,gpa) VALUES('$firstname','$lastname','$email','$gpa')";
    if (mysqli_query($conn, $sql)){
        echo "New record created";
} else {
    echo"Err: ".$sql."<br>".mysqli_error($conn);
}

}
?>

<html>
    <head>
        <title>From Student</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
        <style type="text/css">
            body{font: 14px sans-serif;}
            .wrapper{width: 350px; padding: 20px;}
        </style>
    </head>
    <body>
        
        <div class="form-group" >
            <form method="POST">
            <label>First</label>
            <input type="text" name="firstname" required="">
            <br>
            <label>Last</label>
            <input type="text" name="lastname" required="">
            <br>
            <label>Email</label>
            <input type="email" name="email"required="">
            <br>
            <label>GPA</label>
            <input type="text" name="gpa" required="">
            <br>
            <input type="submit"class="btn btn-info" name="submit" value="SAVE">
            </form>
            <?php
                    $result = mysqli_query($conn, "SELECT * FROM student_01");
                    if ($result->num_rows >0){
                    while ($row = mysqli_fetch_assoc($result)){
            
                        }
                        mysqli_close($conn);
    
                    }
            ?>
            
<!--<form action="<?php htmlspecialchars($_SERVER["PHP_SELF"]) ?>" method="get">
<div class="form-group">
<label for="search">Search: </label>
<div class="input-group">
<input type="text" class="form-control" name="search" id="search" placeholder="search by name" value="<?php (isset($_GET["search"])) ? print($_GET["search"]) : ''; ?>">
<div class="input-group-append">
<button type="submit" class="btn btn-info">Search</button>
</div></div></div></form>
<table class="table">
<thead><tr><th>ID</th><th>Name</th></tr></thead>
<tbody>
<?php
if ($_SERVER["REQUEST_METHOD"] == "GET") {
$input = $sql_search = "";
if (isset($_GET["search"])) {
$input = $_GET["search"];
$sql_search = "SELECT * FROM student WHERE firstname LIKE '%$input%' OR lastname LIKE '%$input%'";
}
if (!empty($input)) {
if (mysqli_query($conn, $sql_search)) {
$search_result = mysqli_query($conn, $sql_search);
if ($search_result->num_rows > 0) {
while ($row = mysqli_fetch_assoc($search_result)) {
?>
<tr><td><?php echo $row['id']; ?></td>
<td><?php echo $row['firstname'] . " " . $row['lastname']; ?></td></tr>
<?php }} else { ?>
<tr><td></td><td>Not found</td></tr>
<?php }} else {
echo "Error: " . $sql_insert . "<br>" . mysqli_error($conn);
}}} ?>
</tbody>
</table>-->
        </div>

    </body>
     
</html>
