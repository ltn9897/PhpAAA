<?php
$mysql_hostName="localhost";
$mysql_userName="root";
$mysql_password="";
$mysql_database="student";
$conn= mysqli_connect($mysql_hostName, $mysql_userName, $mysql_password, $mysql_database);
if(!$conn){
    die("Connection is fail.". mysqli_connect_error());
}
?>
<!DOCTYPE html>
<html>
    <head>
        <title>From Student</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
        <style type="text/css">
            body{font: 14px sans-serif;}
            .wrapper{width: 350px; padding: 20px;}
        </style>
    </head>
    <body>
<form action="<?php htmlspecialchars($_SERVER["PHP_SELF"]) ?>" method="get">
<div class="form-group">
<label for="search">Search: </label>
<div class="input-group">
<input type="text" class="form-control" name="search" id="search" placeholder="search by name" value="<?php (isset($_GET["search"])) ? print($_GET["search"]) : ''; ?>">
<div class="input-group-append">
<button type="submit" class="btn btn-info">Search</button>
</div></div></div></form>
<table class="table">
<thead><tr><th>ID</th><th>Name</th></tr></thead>
<tbody>
<?php
if ($_SERVER["REQUEST_METHOD"] == "GET") {
$input = $sql_search = "";
if (isset($_GET["search"])) {
$input = $_GET["search"];
$sql_search = "SELECT * FROM student WHERE firstname LIKE '%$input%' OR lastname LIKE '%$input%'";
}
if (!empty($input)) {
if (mysqli_query($conn, $sql_search)) {
$search_result = mysqli_query($conn, $sql_search);
if ($search_result->num_rows > 0) {
while ($row = mysqli_fetch_assoc($search_result)) {
?>
<tr><td><?php echo $row['id']; ?></td>
<td><?php echo $row['firstname'] . " " . $row['lastname']; ?></td></tr>
<?php }} else { ?>
<tr><td></td><td>Not found</td></tr>
<?php }} else {
echo "Error: " . $sql_insert . "<br>" . mysqli_error($conn);
}}} ?>
</tbody>
</table>
    </body>
     
</html>