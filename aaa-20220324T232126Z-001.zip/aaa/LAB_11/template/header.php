<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-compatible" content="IE=edge">
        <meta name="viewport" content="width = device-width, initital-scale=1">
        <title><?php echo $title;?></title>
        
        <link href="./bootstrap/bootstrap/css/bootstrap.min.css" rel="stylesheet">
        <link href="./bootstrap/bootstrap/css/bootstrap-theme.min.css" rel="stylesheet">
        <link href="./bootstrap/bootstrap/css/jumbotron.css" rel="stylesheet">
    </head>
    <body>
        <nav class="navbar navbar-inverse navbar-fixed-top">
            <div class="container">
                <div class="navbar-header">
                    <button type= "button" class="navbar-toggle collapse" data-toggle="collapse"
                        data-target="$navbar" aria-expanded ="false" aria-controls="navbar">
                        <span class="sr-only">Toggle navigation</span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                        <span class="icon-bar"></span>
                    </button>
                    <a class="navbar-brand" href="index.php">IT Bookstore</a>
                 </div>
                <div class="navbar-collapse" id="navbar" >
                    <ul class="nav navbar-nav navbar-right">
                        <li><a href="publisher_list.php"><span class="glyphicon glyphicon-paperclip"></span>&nbsp; Publisher</a></li>
                        <li><a href="books.php"><span class="glyphicon glyphicon-book"></span>&nbsp; Books</a></li>
                        <li><a href="contact.php"><span class="glyphicon glyphicon-phone-alt"></span>&nbsp; Contact</a></li>
                        <li><a href=""><span class="glyphicon glyphicon-shopping-cart"></span>&nbsp; My Cart</a></li>
                    </ul>
                </div>
            </div>
        </nav>    
        <div class="container" id="main">
<!--            <hr>
            <footer>
                <div class="text-muted pull-left"></div>
                <div class="text-muted pull-right">Quản ý thư viện sách</div> 
            </footer>
        </div>
        <script type="text/javascript" src="./bootstrap/bootstrap/js/jquery-2.1.4.min.js"></script>
        <script type="text/javascript" src="./bootstrap/bootstrap/js/bootstrap.min.js"></script>-->
    </body>
</html>
