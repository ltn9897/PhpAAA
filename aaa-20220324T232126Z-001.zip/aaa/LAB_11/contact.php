<?php
require_once "./function/database_functions.php";
$conn = db_connect();
//$query = "INSERT INTO contact where id LIKE '$id'";
//$result= mysqli_query($conn, $query);
//if(!$result){
//    echo "Can't retrieve data" . mysqli_error($conn);
//    exit;
//} 
$title = "Phản hồi ý kiến";
require_once "./template/header.php";
?>
<body>
    <div class="container">
            <div class="row">
                <div class="col-lg-4"></div>
            <div class="col-lg-4 form-container">
                <h3 class="text-center">Đóng góp từ độc giả</h3>
                <form method="post" action="" >
                    <div class="form-group">
                        <label>Name</label>
                        <input class="form-control" type="text" name="name" required="" placeholder="Name" >
                    </div>
                    <div class="form-group">
                        <label>Email</label>
                        <input class="form-control" type="email" name="email" placeholder="Email" required="" >
                    </div>
                    <div class="form-group">
                        <label>Ý kiến</label>
                        <textarea class="form-control" name="comment"></textarea>
                    </div>
                    <h6 class="text-center">Ý kiến từ độc giả</h6>
                    <div class="text-center">
                    <input type="reset" class="btn btn-default" name="reset" value="Cancel"/>
                    <input type="submit" class="btn btn-primary" name="submit" value="Submit" />
                    </div>
                </form>
            </div>
            <div class="col-lg-4"></div>
        </div>
    </div>
</body>
<?php
    if(isset($_POST['submit'])){
        $name = $_POST['name'];
        $email = $_POST['email'];
        $comment = $_POST['comment'];
        
        $sql = "INSERT INTO contact SET name='$name',email = '$email', comment = '$comment'";
        $update = mysqli_query($conn, $sql);
        if($update){
            echo "<p class='lead success-text'>Cập nhật thành công <a href='contact.php' class='btn-block'>&larr; Quay lại</a></p>";
        } else {
            echo "<p class='lead error-text'>Phát sinh lỗi</p>";
        }
    }
    ?>