<?php
require_once "./function/database_functions.php";
$conn = db_connect();
$title = "admin-books";
require_once "./template/header.php";
$sql = "SELECT *FROM books";
$data = mysqli_query($conn, $sql);
$total = mysqli_num_rows($data);
$result = mysqli_fetch_all($data,MYSQLI_ASSOC);
if ($total != 0 ){
    echo "";
} else {
echo "No reords Found";    
}
$query = "SELECT book_image FROM books";
$img= mysqli_query($conn, $query);
if(!$img){
    echo "Can't retrieve data" . mysqli_error($conn);
    exit;
} 
?>
<a href="" class="container">Add new book</a>
<button class="btn btn-info"><a href="admin.php">Sign out</a></button>
<body>
    <div class="col-lg-12">
        <div class="row text-center">
        <form style="border-top: ridge ;border-bottom: ridge">
            <table class="table">
        <tr>
            <th>ISBS</th>
            <th>Title</th>
            <th>Author</th>
            <th>Image</th>
            <th>Description</th>
            <th>Price</th>
            <th>Publisher</th>
        </tr>
        </table>
        </form>
    </div>
    </div>
    <tbody>
<?php
    foreach ($result as $value){
        ?>
      <table class="table ">
<tr>
            <td><?php echo $value['book_isbn'];?></td>
            <td><?php echo $value['book_title'];?></td>
            <td><?php echo $value['book_author'];?></td>
            <td><?php echo $value['book_image'];?></td>
            <td><?php echo $value['book_descr'];?></td>
            <td><?php echo $value['book_price'];?></td>
            <td><?php echo $value['publisherid'];?></td>
  </tr>
  </table>
  <?php
            }
?>
      </tbody>
         </table>
            </div>
        </div>
        </div>
</body>

