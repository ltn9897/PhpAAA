<?php
require_once "./function/database_functions.php";
$conn = db_connect();
$title = "admin";
require_once "./template/header.php";
?>
<?php
    $username = $password = "";
    $username_err = $password_err="";
    if($_SERVER['REQUEST_METHOD'] == "POST"){
        $username = trim($_POST['username']);
        $password = trim($_POST['password']);
        empty($username) ? $username_err = "Username can't blank" : '';
        (strlen($password) < 6) ? $password_err = "Password must have 6 char":'';
        if(empty($username_err) && empty($password_err)){
                session_start();
                if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
            header("location:admin-books.php");
                exit();
           }
         }
    }
?>
<body>
    <div class="container">
        <form action="<?php htmlspecialchars($_SERVER["PHP_SELF"]) ?>" method="POST">
            <div class="form-group text-center">
            <label>Username</label>
            <input type="text" name="username" value="<?php echo $username;?>">
            <span id="" class="form-group text-muted"><?php echo "$username_err"; ?></span>
            </div>
            <div class="form-group  text-center">
            <label>Password</label>
            <input type="password" name="password" value="<?php echo $password;?>">
            <span id="" class="form-group text-muted"><?php echo "$password_err"; ?></span>
            </div>
            <div>
                <input type="button" name="submit" class="btn btn-primary" value="Submit">
            </div>
          </form>
    </div>
</body>
<?php 
require_once "./template/footer.php";
?>