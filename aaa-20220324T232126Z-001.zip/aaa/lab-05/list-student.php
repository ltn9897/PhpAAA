<?php
session_start();
 if(!isset($_SESSION["username"])){
     echo '<a href "Login.php">Đăng nhập</a>';
 } else {
     
}
?>

<?php
$mysql_hostName="localhost";
$mysql_userName="root";
$mysql_password="";
$mysql_database="student";
$conn= mysqli_connect($mysql_hostName, $mysql_userName, $mysql_password, $mysql_database);
//print_r($conn);
if(!$conn){
    die("Connection is fail.". mysqli_connect_error());
}
?>

<div class="container">
    <div class="row mt-5">
        <div class="col">
            <div>
                <a href="logout.php">Đăng xuất</a>
            </div>
            <table class="table">
                <thread>
                    <tr>
                        <th scope="col">ID</th>
                        <th scope="col">First</th>
                        <th scope="col">Last</th>
                        <th scope="col">Email</th>
                        <th scope="col">GPA</th>
                    </tr>
                </thread>
                <tbody>
                    <?php
                    $result = mysqli_query($conn, "SELECT *FROM student");
                    if ($result->num_rows >0){
                    while ($row = mysqli_fetch_assoc($result)){
                        ?>
                    <tr>
                        <td><?php echo $row["id"]; ?></td>
                        <td><?php echo $row["firstname"]; ?></td>
                        <td><?php echo $row["lastname"]; ?></td>
                        <td><?php echo $row["email"]; ?></td>
                        <td><?php echo $row["gpa"]; ?></td>
                    </tr>
                    <?php
                        }
                    }
                    ?>
                </tbody>
            </table>
        </div>
    </div>
</div>