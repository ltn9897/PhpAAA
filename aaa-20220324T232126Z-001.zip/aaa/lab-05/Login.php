<!DOCTYPE html>
<?php
define('DB_SERVER', 'Localhost');
define('DB_USERNAME', 'root');
define('DB_PASSWORD', '');
define('DB_NAME', 'student');

$link = mysqli_connect(DB_SERVER, DB_USERNAME, DB_PASSWORD, DB_NAME);
if($link === false){
    die("ERROR :Could not connect.".mysqli_connect_error());
}
?>
<?php
session_start();
if(isset($_SESSION["loggedin"]) && $_SESSION["loggedin"] === true){
    header ("location:list-student.php");
    exit();
   }
$username = $password = "";
$username_err=$password_err="";

?>

<html lang="en">
    <head>
        <title>Login</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
        <style type="text/css">
            body{font: 14px sans-serif;}
            .wrapper{width: 350px; padding: 20px;}
        </style>
    </head>
    <body>
        <div class="wrapper">
            <h2>Login</h2>
            <p>please fill this form to create an account</p>
            <form action="<?php htmlspecialchars($_SERVER["PHP_SELF"]) ?>" method="POST">
                <div class="form-group <?php echo (!empty($username_err))?'has-error' :'';?>">
                    <label>Username</label>
                    <input type="text" name="username" class="form-control" required="" value="<?php echo $username;?>">
                    <span class="help-block"><?php echo $username_err;?></span>
                    <?php
                        
                    ?>
                    </div>   
                <div class="form-group<?php echo (!empty($password_err))?'has-error' :'';?>">
                    <label>Password</label>
                    <input type="password" name="password" class="form-control" value="<?php echo $password;?>">
                    <span class="help-block"><?php echo $password_err;?></span>
                    </div>
                <div class="form-group">
                <input type="submit" class="btn btn-info" value="Login">
                </div>
            </form>
        </div>
    </body>
</html>
