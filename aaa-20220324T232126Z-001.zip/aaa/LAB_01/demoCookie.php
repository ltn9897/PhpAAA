<?php

$Month = 86400 + time();
setcookie('Name','Nam',$Month);
echo 'The cookie has been set.';

?>