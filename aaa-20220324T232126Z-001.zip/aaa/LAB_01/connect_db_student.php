<?php
$hostName="localhost";
$userName="root";
$password="";
$dbName="student";
$conn= mysqli_connect($hostName, $userName, $password, $dbName);
print_r($conn);
//$db = mysqli_select_db($conn, $dbName);
//if(!$db){
//    die("Connection is fail.");
//} else {
//    echo"Connected database "+ $dbName;
//}

?>

