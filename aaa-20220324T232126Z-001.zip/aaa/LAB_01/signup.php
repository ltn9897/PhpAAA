<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <title>Document</title>
</head>
<body">
    <div class ="container">
     <div class = "col-md-6 offset-md-2" style = "border: gray solid medium; padding: 1em; background-color: #7eacbb">
            <h2>Sign-up</h2>
            <hr>
            <form action = "signup_process.php" method = "Post" name = "formSIGNUP">
            <div class = "form-group">
                <label>User name</label>
                  <input name = "user" id = "user" value = "aptech" required class="form-control"/>
              </div> 

              <div class = "form-group"> 
                <label>Password</label>
                  <input name = "pass" id="pass" value = "123" required type="password" class= "form-control"/>
              </div>

              <div class="form-group">
                  <label>Email</label>
                  <input name = "email" id = "email" value="aptech@gmail.com" required type="email" class="form-control"/>
              </div>

              <div class="form-group">
                  <label>Phone</label>
                  <input name="phone" id="phone" value="0909090909" required pattern="^\d{3,12}$" class="form-control"/>
              </div>

              <div class="form-group">
                  <label>Location</label>
                  <select name="location" id="location" class="form-control">
                    <option selected>Choose...</option>
                    <option value="Sai Gon">Sai Gon</option>
                    <option value="Ha Noi">Ha Noi</option>
                    <option value="Hue">Hue</option>
                  </select>
              </div>

                <div class="form-group">

                    <div class="form-check-inline">
                        <label class="form-check-label">
                            Gender
                        </label>
                    </div>
                    <div class="form-check-inline">
                        <label class="form-check-label">
                            <input type="radio" class="form-check-input" value="male" name="gender">Male
                        </label>
                    </div>
                    <div class="form-check-inline disabled">
                        <label class="form-check-label">
                            <input type="radio" class="form-check-input" value="female" name="gender">Female
                        </label>
                    </div>
                </div>

              <div class="form-group">
                <div class="form-check-inline">
                    <label class="form-check-label">
                        Language
                    </label>
                </div>
                <div class="form-check-inline">
                    <label class="form-check-label">
                        <input type="checkbox" class="form-check-input" value="EnglisH  " name="lang[]">English
                    </label>
                </div>
                <div class="form-check-inline">
                    <label class="form-check-label">
                        <input type="checkbox" class="form-check-input" value="France" name="lang[]">France
                    </label>
                </div>
                <div class="form-check-inline">
                    <label class="form-check-label">
                        <input type="checkbox" class="form-check-input" value="Russia" name="lang[]">Russia
                    </label>
                </div>
            </div>

              <div>
                <input type ="submit" value= "submit" name= "btOK" class="btn btn-danger">
                <input type ="reset" value="reset" class="btn btn-info">
              </div>
      </div>
    </div>
</body>
</html>