<?php

$name = $_POST["name"];
$age = $_POST["age"];
//$phone = $_GET["phone"];

echo "hello $name  <br> $age ";