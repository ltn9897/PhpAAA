<!DOCTYPE html>
<html>
    <head>
        <title>TODO supply a title</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>
    <body>
        <form action="demo_01.php" method="Post">
            <div>
                <label>Name :</label>
                <input name="name" id="name">
            </div>
            <div>
                <label>Age :</label>
                <input name="age" id="age">
            </div>
            <input type="submit" value="submit" />
        </form>
    </body>
</html>