<?php
$connect = mysqli_connect('localhost','root','');
$db_list= mysqli_query($connect, 'SHOW DATABASES');
$result = mysqli_fetch_all($db_list);
foreach ($result as $value) {
    echo "".print_r($value)."<br>";
}

?>
<?php


?>