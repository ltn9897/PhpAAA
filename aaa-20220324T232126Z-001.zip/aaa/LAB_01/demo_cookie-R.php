<?php
if(isset($_COOKIE['Name'])){
    $last = $_COOKIE['Name'];
    echo"welcome back <br> your name is" . $last;
}else{
    echo "Welcome to out side";
    
}
?>

