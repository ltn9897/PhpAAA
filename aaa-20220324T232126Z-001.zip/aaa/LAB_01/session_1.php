<?php

session_start();
echo "The Session id is".session_id(). "<br>";
?>