<?php
//first method to create aaray
$numbers = array(1,2,3,4,5);
foreach ($numbers as $value) {
    echo "value is $value <br>";
}
//Second method to create a method
$numbers[0]="one";
$numbers[1]="two";
$numbers[2]="three";
$numbers[3]="four";
$numbers[4]="five";
foreach ($numbers as $value) {
    echo "value is $value<br>";
}
?>
<?php 
//
$salaries = array("tuan"=>2000,"teo"=>1000,"ty"=>500);
echo"Salaries of tuan is ".$salaries['tuan']."<br>";
echo"Salaries of teo is ".$salaries['teo']."<br>";
echo"Salaries of ty is ".$salaries['ty']."<br>";
//
$salaries['tuan']="high";
$salaries['teo']="medium";
$salaries['ty']="low";

echo"Salaries of tuan is ".$salaries['tuan']."<br>";
echo"Salaries of teo is ".$salaries['teo']."<br>";
echo"Salaries of ty is ".$salaries['ty']."<br>";
?>

<?php
$marks = array (
    "tuan" =>array(
        "physics"=>35,
        "math"=>50,
        "chemistry"=>60,
        "english"=>array(
            "score"=>30,
            "comment"=>"good"
        )
),
    "teo" =>array(
        "physics"=>45,
        "math"=>55,
        "chemistry"=>65
),
    "ty" =>array(
        "physics"=>55,
        "math"=>55,
        "chemistry"=>65
)   
);
//print_r($marks);
 echo"mark physics of tuan: ";
 echo $marks['tuan']['physics']."<br>";
 echo"mark english of tuan: ";
 echo $marks['tuan']['english']['comment']."<br>";
 echo"mark math of teo: ";
 echo $marks['teo']['math']."<br>";
 echo"mark chemistry of ty: ";
 echo $marks['ty']['chemistry']."<br>";