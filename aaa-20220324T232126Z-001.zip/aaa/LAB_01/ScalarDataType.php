<?php

//function test1(int$x){
//    echo 'interger $x = ' .$x;
//}
//    test1(10.124);
//    
//    function test2(float $y){
//        echo 'float $y='.$y;
//    }
//    test2(true);
declare (strict_types =1);
function test2(int $a){
        echo $a;
    }
    test2(true);

?>