<?php
    if(empty($_POST["btOK"])){
        header("location:signup.php");
        exit();
    }

    $name = $_POST["user"];
    $pass = $_POST["pass"];
    $email = $_POST["email"];
    $phone = $_POST["phone"];
    $location = $_POST["location"];
    $gender = $_POST["gender"];
    if (empty ($_POST["lang"])) {
        $lang = "None";
    }
    else{
        $lang = $_POST["lang"];
    }

    echo "$name <br> $pass <br> $email <br> $phone <br> $location <br> $gender <br>";
    if ($lang == null) {
        echo "Language: none";
    }   
    else {
        foreach ($lang as $i) {
            echo "$i ";
        }
    }
?>