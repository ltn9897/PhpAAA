<?php

php_ini_loaded_file();
?>
