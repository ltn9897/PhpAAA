<?php
$host = "Localhost";
$username = "root";
$password = "";
$dbname = "employee";
$UploadFoler = "C:\\xampp\\htdocs\\LAB_06\\";
$linkUpload = "http://localhost:8098/LAB_06/";
$avatarDefault="C:\Users\LETHANHNAM\Desktop\Thư mục mới (3)\hoa\\";
$conn = mysqli_connect($host,$username,$password,$dbname);
if($conn){
    echo "";
} else {
    die("ERROR :Could not connect.".mysqli_connect_error());
}
?>
