<?php
error_reporting(0);
include ("config.php");
$rn = $_GET['rn'];
$nm = $_GET['sn'];
$cl= $_GET ['cl'];
$id = $_GET['id'];
?>
<head>
        <title>From Student</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
        <style type="text/css">
            body{font: 14px sans-serif;}
            .wrapper{width: 350px; padding: 20px;}
        </style>
    </head>
<body>
    <div class="container-fluid px-5">
        <div class="row">
            <div class="col-lg-4"></div>
            <div class="col-lg-4 form-container">
                <h4 class="text-center">Update</h4>
                
                <form method="post" action="" enctype="multipart/form-data">
                    <div class="form-group">
                        <label>Mã nhân viên</label>
                        <input class="form-control" type="text" name="rollno" placeholder="Mã nhân viên..." value="<?php echo $rn;?>"/>
                    </div>
                    <div class="form-group">
                        <label>Tên nhân viên</label>
                        <input class="form-control" type="text" name="name" placeholder="Tên nhân viên..." value="<?php echo $nm;?>"/>
                    </div>
                    <div class="form-group">
                        <label>Đơn vị</label>
                        <input class="form-control" type="text" name="department" placeholder="Đơn vị..." value="<?php echo $cl;?>"/>
                    </div>
                    <input type="submit" class="btn btn-primary btn-block" name="submit" value="Cập nhật" />
                    <input type="hidden" name="id" value="<?php echo $id;?>"
                    
                </form>
            </div>
            <div class="col-lg-4"></div>
        </div>
    </div>
    <?php
    if($_POST['submit']){
        $name = $_POST['name'];
        $department = $_POST['department'];
        $rollno = $_POST['rollno'];
        
        $sql = "UPDATE employee SET rollno='$rollno',name = '$name', department = '$department',  WHERE id = '$id'";
        $update = mysqli_query($conn, $sql);
        print_r($sql);
        print_r($update);
        if($update){
            echo "<p class='lead success-text'>Cập nhật thành công <a href='read.php' class='btn-block'>&larr; Quay lại</a></p>";
        } else {
            echo "<p class='lead error-text'>Phát sinh lỗi</p>";
        }
    }
    ?>