<!DOCTYPE html>
<?php
include ("config.php");
$sql = "SELECT *FROM employee";
$data = mysqli_query($conn, $sql);
$total = mysqli_num_rows($data);
$result = mysqli_fetch_all($data,MYSQLI_ASSOC);
if ($total != 0 ){
    echo "";
} else {
echo "No reords Found";    
}
?>
<html>
    <head>
        <meta charset="UTF-8">
        <title>Danh sách nhân viên</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
        <style type="text/css">
            body{font: 14px sans-serif;}
            .wrapper{width: 350px; padding: 20px;}
        </style>
    </head>
    <body>
        <div class="container pt-1">
            <h3 class="text-center">Thông tin nhân viên</h3>
            <a href="search.php">Search :</a>
            <div class="row text-center">
                <div class="col-lg-12">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Mã nhân viên</th>
                            <th>Tên nhân viên</th>
                            <th>Đơn vị</th>
                            <th>Hình ảnh</th>
                            <th colspan="2">Update or delete</th>
                        </tr>
                    </thead>
                
    <tbody>
<?php
    foreach ($result as $value){
        ?>
<tr>
            <td><?php echo $value['rollno'];?></td>
            <td><?php echo $value['name'];?></td>
            <td><?php echo $value['department'];?></td>
            <td><img src="<?php echo $value['img'] ? $linkUpload.$value['img']: $avatarDefault?>" width="80" height="80"></td>
            <td><a href="Update.php?rn=<?php echo $value['rollno'];?> & sn=<?php echo $value['name'];?> &cl=<?php echo $value['department'];?> &id=<?php echo $value['rollno'];?>"
                   class="btn btn-primary btn-sn">Update</a></td>
                   <td><a onclick="return checkDelete()" href="delete.php?rollno=<?php echo $value['rollno'];?>" class="btn btn-danger btn-sm">Delete</a></td>  
  </tr>
  <?php
            }
?>
  
      </tbody>
         </table>
            </div>
        </div>
        </div>
        <script type="text/javascript">
            function checkDelete(){
                return confirm("Bạn có chắc muốn xoá ?");
            }
            </script>
    </body>
</html> 


