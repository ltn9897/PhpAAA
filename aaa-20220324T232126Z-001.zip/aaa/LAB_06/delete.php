<div class="container mt-5 text-center">
<?php
error_reporting(0);
include ("config.php");
$id = $_GET['rollno'];
$sql = "DELETE FROM employee WHERE rollno = '$id'";
$data = mysqli_query($conn, $sql);
if($data){
    echo "<p class='lead success-text'>Xoá thành công</p>";
} else {
     echo "<p class='lead error-text'>Lỗi phát sinh!!</p>";
}
?>
    <a class="btn btn-info btn-sm mt-3" href="read.php">Go back to previous page</a>
</div>
