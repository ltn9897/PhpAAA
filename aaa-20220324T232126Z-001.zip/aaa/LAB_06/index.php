<!DOCTYPE html>

<html>
    <head>
        <meta charset="UTF-8">
        <title>Đăng ký nhân viên</title>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
        <style type="text/css">
            body{font: 14px sans-serif;}
            .wrapper{width: 350px; padding: 20px;}
        </style>
    </head>
    <body>
        <div class="container">
            <div class="row">
                <div class="col-lg-4"></div>
            <div class="col-lg-4 form-container">
                <h4 class="text-center">Đăng ký nhân viên</h4>
                
                <form method="POST" action="" enctype="multipart/form-data">
                    <div class="form-group">
                        <label>Mã nhân viên</label>
                        <input class="form-control" type="text" name="rollno" required="" placeholder="Mã nhân viên.." >
                    </div>
                    <div class="form-group">
                        <label>Tên nhân viên</label>
                        <input class="form-control" type="text" name="name" placeholder="Tên nhân viên.." required="">
                    </div>
                    <div class="form-group">
                        <label>Đơn vị</label>
                        <input class="form-control" type="text" name="department" placeholder="Đơn vị.." required="">
                    </div>
                    <div class="form-group">
                        <label>Hình ảnh nhân viên</label>
                        <input class="form-control-file" type="file" name="upload_file"/>
                    </div>
                    <input type="submit" class="btn btn-primary btn-block" name="submit" value="Submit" />
                </form>
            </div>
            <div class="col-lg-4"></div>
        </div>
    </div>
    </body>
</html>
<?php 
include ("config.php");
?>
<?php
if($_SERVER["REQUEST_METHOD"] =="POST"){
   $rollno = $_POST["rollno"];
   $name = $_POST["name"];
   $department = $_POST["department"];
   //img upload
   $file_name = $_FILES["upload_file"]["name"];
   $temp_name = $_FILES["upload_file"]["tmp_name"];
   $dir = $UploadFoler;
   move_uploaded_file($temp_name, $dir . $file_name);

    if($rollno != "" && $name =!"" && $department != ""){
        $sql = "INSERT INTO employee (rollno,name,department,img) VALUES ('$rollno','$name','$department','$file_name')";
      $data = mysqli_query($conn, $sql);
      if($data){
          echo "<p class='text-center success-text mt-2'>Thông tin nhân viên đã được lưu</p>";
      }
        } else {
            echo"<p class='text-center error-text mt-2'>Xem lại thông tin</p>";
        }
    }

?>