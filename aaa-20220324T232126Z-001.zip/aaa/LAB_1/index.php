<!DOCTYPE html>
<html>
    <head>
        <meta charset="UTF-8">
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
    <title>Đăng kí nhân viên</title>
    <style type="text/css">
        body{font: 14px sans-serif;}
        wrapper{width: 350px; padding: 20px}
    </style>
    </head>
    <body>
        <div class="col">
            <div class="row">
                <form method="Post" action="emp-detail.php">
                    <div class="form-group">
                        <label> Mã nhân viên:</label>
                        <input type="text" class="form-control" placeholder="Mã nhân viên" id="id" name="id">
                    </div>
                    <div class="form-group">
                        <label>Tên nhân viên :</label>
                        <input type="text" class="form-control" placeholder="Tên nhân viên" id="name" name="name">
                    </div>
                    <div class="form-group">
                        <label>Phòng ban</label>
                        <input type="text" class="form-control" placeholder="Phòng ban" id="department" name="department">
                    </div>
                    <div class="form-control form-check">
                        <label class="form-check-label">
                            <input class="form-check-input" type="checkbox" name="remember">Lưu lại
                        </label>
                        <button type="submit" class="btn-btn-promary">Lưu lại</button>
                </form>
            </div>
        </div>
    </body>
</html>
