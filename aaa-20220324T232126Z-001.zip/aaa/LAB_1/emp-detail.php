<?php

$id=$_POST["id"];
$name=$_POST["name"];
$department=$_POST["department"];
$remember = $_POST["remember"];

echo"<h2> Thông tin nhân viên</h2>";
echo"<br>";

echo'ID:' . $id."<br>";
echo'NAME:' . $name."<br>";
echo'DEPARTMENT:' . $department."<br>";
echo'REMEMBER:' . $remember."<br>";
